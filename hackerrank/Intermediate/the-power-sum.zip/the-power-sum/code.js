/*
 * Complete the 'powerSum' function below.
 *
 * The function is expected to return an INTEGER.
 * The function accepts following parameters:
 *  1. INTEGER X
 *  2. INTEGER N
 */

function powerSum(X, N) {    
    // Write your code here
    let ans = 0;
    
    const calc = (sum, m) => {
      if( sum < 0) return ;
      if(sum == 0) {
        ans ++;
        return ;
      } 
      let i = m
      const end = Math.pow(sum, 1 / N) + 1
      
      for(let i = m; i <= end; i ++) {
        const p = Math.pow(i, N);        
        calc(sum - p, i + 1)
      }
    }
    
    calc(X, 1)
    
    return ans
}
