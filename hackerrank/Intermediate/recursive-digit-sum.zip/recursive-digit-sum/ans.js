function superDigit(n, k) {
  // Write your code here

  let nn = '' + n
  let kk = +k
  while (nn.length > 1 || kk > 1) {
    if (nn.length == 1) {
      if (kk == 1) break
      nn = +nn * kk + ''
      kk = 1
    }
    let sum = 0
    for (let v of nn) sum += +v
    nn = '' + sum
  }
  return nn
}

console.log(superDigit('148', 3))
